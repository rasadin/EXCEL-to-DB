CREATE TABLE IF NOT EXISTS `user_details` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `country` varchar(50) NOT NULL
);
